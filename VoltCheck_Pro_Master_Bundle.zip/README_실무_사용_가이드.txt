================================================================================
VOLTCHECK 24V PROFESSIONAL OFFLINE MASTER ENGINEERING BUNDLE v3.0
================================================================================
구매해 주셔서 대단히 감사합니다.
본 패키지는 산업용 제어선로, 공장 자동화(FA), 반도체/2차전지 플랜트 전장설계를 위한
26대 공학 계산 마스터 엑셀 서식 및 AutoCAD/EPLAN 표준 심볼 라이브러리입니다.

[포함된 실무 패키지 구성]
1. VoltCheck_24V_Engineering_Master_Workbook.csv (26대 공학 연산 수식 내장 엑셀 통합본)
2. AutoCAD_EPLAN_Standard_CAD_Symbols_200.dxf (공인 회로 기호 200종 DXF)
3. IEC_60204-1_NFPA_79_KEC_Control_Standards_Guide_2026.txt (글로벌 규격 실무 가이드북)
4. Commercial_Engineering_Perpetual_License.txt (영구 상업용 라이선스 증서)

[기술 지원 및 평생 무상 개정판 문의]
- 웹사이트: https://voltcheck24.com/
- 이메일: jiwan0028@gmail.com
- 저작권자: VoltCheck Engineering Lab (이규정)
================================================================================
