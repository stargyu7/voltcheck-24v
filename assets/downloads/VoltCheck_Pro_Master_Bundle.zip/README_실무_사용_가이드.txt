================================================================================
VOLTCHECK 24V - LEGAL DISCLAIMER, TERMS & PERPETUAL COMMERCIAL LICENSE
================================================================================

[1. 엔지니어링 면책 조항 (ENGINEERING DISCLAIMER & LIMITATION OF LIABILITY)]
1. 본 패키지에 포함된 26대 공학 계산 엑셀(XLSX/CSV), AutoCAD/EPLAN CAD 심볼(DXF),
   및 실무 규격 가이드북은 공인된 국제 전기 규격(IEC, NFPA, ISO, KEC)의 기본 물리
   수식을 기반으로 제작된 '설계 참조용 기술 자료(AS-IS)'입니다.
2. 실제 배선 시공, 차단기/변압기/서보모터 선정 및 현장 설치 전 반드시 프로젝트 책임
   유자격 기술자(전기기사/기술사/감리원)의 현장 실측 및 최종 승인을 거쳐야 합니다.
3. 서비스 제공자(VoltCheck Engineering Lab 및 개발자)는 본 데이터 및 수식의 활용으로
   인해 발생하는 직·간접적 손해, 설비 손상, 공사 지연, 법적 분쟁에 대해 일체의
   민·형사상 책임을 부담하지 않습니다.

[2. 무보증 원칙 (NO WARRANTY)]
본 패키지는 상품성 및 특정 목적에 대한 적합성을 포함하여 어떠한 형태의 명시적 또는
묵시적 보증 없이 '있는 그대로(AS-IS)' 제공됩니다.

[3. 상표권 공정 이용 (NOMINATIVE FAIR USE)]
본 자료에 언급된 제조사명(Siemens, Mitsubishi, LS ELECTRIC, Omron, Mean Well 등)은
규격 호환성 설명을 위한 순수 공정 이용(Nominative Fair Use) 목적으로만 사용되었습니다.

[4. 영구 상업용 라이선스 (COMMERCIAL PERPETUAL LICENSE)]
- 구매자(개인 또는 기업)는 본 패키지를 프로젝트 설계 도면 작성 및 고객사 납품용
  기술검토서 작성에 영구적으로 자유롭게 사용할 수 있습니다.
- 단, 파일 자체의 무단 재배포, 온라인 재판매, 공유 사이트 업로드는 금지됩니다.

문의 및 기술지원: jiwan0028@gmail.com
저작권: (c) 2026 VoltCheck Engineering Lab. All rights reserved.
================================================================================
